
function foo() {
	bar(1)
}
function bar(arg) {
	console.log('yes, ' + arg)
}
foo()