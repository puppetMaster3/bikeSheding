console.log ("ready 0.1")

//LOOK at LAB1.PDF

